#include <iostream>
#include <glut.h>
#include <math.h>
#include "windows.h"

using namespace std;

float rx = 0.0;
float ry = 0.0;
float rz = 0.0;


void AmbientLighting()
{
    glEnable(GL_LIGHTING);

    double amb = .3;
    GLfloat global_ambient[] = { amb,amb,amb, 0.1 };
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);
}

void PointLight(const float x, const float y, const float z, const float amb, const float diff, const float spec)
{
    glEnable(GL_LIGHTING);

    /*
    GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    */
    GLfloat light_ambient[] = { amb,amb,amb, 0.5 };
    GLfloat light_diffuse[] = { diff, diff, diff, 0.5 };
    GLfloat light_specular[] = { spec, spec, spec, 0.5 };

    GLfloat light_position[] = { x + rx,y + ry,z + rz, 0.5 };

    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glEnable(GL_LIGHT0); //enable the light after setting the properties

}

void DrawSphere(const float radius, const float alpha)
{
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
    glColor4f(0.4f, 0.4f, 0.7f, alpha);

    //equivalent to doing this:
    //float diffuse[4] =  {1.0f, 1.0f, 0.0f, alpha};
        //glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);


    GLUquadricObj* quadratic;
    quadratic = gluNewQuadric();
    gluQuadricNormals(quadratic, GLU_SMOOTH);
    gluSphere(quadratic, radius, 35, 35);
}

void LookAt()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(190, 5, 3, 100);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(10, -0, 15, 5, 0, 10, 0, 1, 0);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);


    DrawSphere(5.2, .2);

    AmbientLighting();
    PointLight(2, 2, 2, 0, 1, 1);

    glutSwapBuffers();
}

float a = 0.0;
void specialKeys(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_LEFT:
        a -= 0.5;
        break;
    case GLUT_KEY_RIGHT:
        a += 0.5;
        break;
    }
    rx = 1;
    ry = a;
    rz = a;
    //std::cout << a << " " << rx << " " << ry << " \n";
    glutPostRedisplay();

}


void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
}


int WindowHeight = 1000;
int WindowWidth = 1000;

int main(int argc, char* argv[])
{
    glutInit(&argc, argv);
    //glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(WindowWidth, WindowHeight);
    glutInitWindowPosition(0, 0);

    glutCreateWindow("Lighting Example");

    glDepthFunc(GL_LESS);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(specialKeys);


    //PointLight(10,10,10);
    //PointLight(0,0,0, 0, 1, 1);

    LookAt();

    glutMainLoop();

    return 0;
}

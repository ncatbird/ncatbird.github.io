﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _35_1_Drozdov_neuronumbers.ModelNeuroNet
{
    enum TypeNeuron { HiddenLayer,OutputLayer }
    enum MemoryMode { Get,Set,Init }
    enum NetworkMode { Train, Test, Rec}
}

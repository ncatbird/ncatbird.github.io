﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using _35_2_Baranova_meowCIFERKAmeow.ModelNeuroNet;

namespace _35_2_Baranova_meowCIFERKAmeow
{
    public partial class Form_Main : Form
    {
        // поля
        double[] inpupData = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };  // массив входных данных
        NeuroNet net;
        
        // свойства

        // конструктор
        public Form_Main()
        {
            InitializeComponent();
            net = new NeuroNet(NetworkMode.Demo);
        }

        // изменение статуса входных данных
        void ChangeStatusData(Button b,int index) 
        {
            if (b.BackColor == Color.White)
            {
                b.BackColor = Color.Black;
                inpupData[index] = 1;
            }
            else
            {
                b.BackColor = Color.White;
                inpupData[index] = 0;
            }
        }

        #region Обработчики кнопок пикселей

        private void button1_Click(object sender, EventArgs e) => ChangeStatusData(button1, 0); // клик по кнопке 1        
        private void button2_Click(object sender, EventArgs e) => ChangeStatusData(button2, 1); // клик по кнопке 2        
        private void button3_Click(object sender, EventArgs e) => ChangeStatusData(button3, 2); // клик по кнопке 3
                                                                                       
        private void button4_Click(object sender, EventArgs e) => ChangeStatusData(button4, 3); // клик по кнопке 4
        private void button5_Click(object sender, EventArgs e) => ChangeStatusData(button5, 4); // клик по кнопке 5        
        private void button6_Click(object sender, EventArgs e) => ChangeStatusData(button6, 5); // клик по кнопке 6
        private void button7_Click(object sender, EventArgs e) => ChangeStatusData(button7, 6); // клик по кнопке 7
        private void button8_Click(object sender, EventArgs e) => ChangeStatusData(button8, 7); // клик по кнопке 8       
        private void button9_Click(object sender, EventArgs e) => ChangeStatusData(button9, 8); // клик по кнопке 9
        private void button10_Click(object sender, EventArgs e) => ChangeStatusData(button10, 9); // клик по кнопке 10
        
        private void button11_Click(object sender, EventArgs e) => ChangeStatusData(button11, 10); // клик по кнопке 11

        private void button12_Click(object sender, EventArgs e) => ChangeStatusData(button12, 11); // клик по кнопке 12


        private void button13_Click(object sender, EventArgs e) => ChangeStatusData(button13, 12); // клик по кнопке 13

        private void button14_Click(object sender, EventArgs e) => ChangeStatusData(button14, 13); // клик по кнопке 14

        private void button15_Click(object sender, EventArgs e) => ChangeStatusData(button15, 14); // клик по кнопке 15
        #endregion
        private void button_SaveTrainSample_Click(object sender, EventArgs e)
        {
            string pathFileTrainSample = AppDomain.CurrentDomain.BaseDirectory + "trainSample.txt";
            string strSample = numericUpDown_Cifra.Value.ToString();
            for (int i = 0; i < inpupData.Length; i++)
            {
                strSample += " " + inpupData[i].ToString();
            }
            strSample += "\n";

            File.AppendAllText(pathFileTrainSample, strSample);
        }

        private void button_raspoznat_Click(object sender, EventArgs e)
        {
            net.ForwardPass(net, inpupData);
            label1.Text = net.fact.ToList().IndexOf(net.fact.Max()).ToString();
        }
    }
}

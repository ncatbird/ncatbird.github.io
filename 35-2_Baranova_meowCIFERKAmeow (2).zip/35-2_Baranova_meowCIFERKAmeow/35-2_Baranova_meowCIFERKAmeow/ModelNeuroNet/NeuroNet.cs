﻿using System;


namespace _35_2_Baranova_meowCIFERKAmeow.ModelNeuroNet
{

    class NeuroNet
    {
        //массив для хранения вектора выходного сигнала нейросети
        public double[] fact = new double[10];
        //все слои нейросети
        private InputLayer input_layer=null;
        private HiddenLayer hidden_layer1 = new HiddenLayer(70, 15, TypeNeuron.Hidden, nameof(hidden_layer1));
        private HiddenLayer hidden_layer2 = new HiddenLayer(32, 70, TypeNeuron.Hidden, nameof(hidden_layer2));
        private OutputLayer output_layer = new OutputLayer(10, 32, TypeNeuron.Output, nameof(output_layer));

        //среднее значение энергии ошибки эпохи обучения
        private double e_error_avr;

        //свойства
        public double E_error_avr { get => e_error_avr; set => e_error_avr = value; }

        //конструктор
        public NeuroNet(NetworkMode nm)
        {
            input_layer = new InputLayer(nm);
        }

        //прямой проход синала по нейросети
        public void ForwardPass(NeuroNet net, double[] netInput)
        {
            net.hidden_layer1.Data = netInput;
            net.hidden_layer1.Recognize(null, net.hidden_layer2);
            net.hidden_layer2.Recognize(null, net.output_layer);
            net.output_layer.Recognize(net, null);
        }

    }
}

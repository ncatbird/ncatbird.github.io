﻿using System;


namespace _35_2_Baranova_meowCIFERKAmeow.ModelNeuroNet
{
   
   enum MemoryMode//режимы работы памяти
    {
        GET,
        SET,
        INIT
    }
    
    enum TypeNeuron { Hidden, Output }

    enum NetworkMode
    { 
        Train,
        Test,
        Demo
    }


}

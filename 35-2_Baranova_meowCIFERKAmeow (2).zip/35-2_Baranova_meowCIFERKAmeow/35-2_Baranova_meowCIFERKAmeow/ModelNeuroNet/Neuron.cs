﻿using System;
using static System.Math;

namespace _35_2_Baranova_meowCIFERKAmeow.ModelNeuroNet
{
    class Neuron
    {
        //поля
        TypeNeuron type;
        private double[] inputs;
        private double[] weights;
        private double output;
        private double derivative;

        //свойства
        public double[] Weights { get { return weights; } set { weights = value; } }
        public double[] Inputs { get { return inputs; } set { inputs = value; } }
        public double Output{ get { return output; } }
        public double Derivative {get { return derivative; } }
        //конструктор
        public Neuron(double[] inpts, double[] wght, TypeNeuron ntype)
        { inputs = inpts; weights = wght; type = ntype; }
        public double[] Input
        {
            get { return inputs; }
            set { inputs = value; }
        }
        // методы
        public void Activator()
        {
            double sum;
            sum = weights[0];
            for (int i = 0; i < inputs.Length; i++)
            {
                sum += inputs[i] * weights[i + 1];
            }
            switch (type)
            {
                case TypeNeuron.Hidden:
                    output = Logistic(sum);
                    derivative = Logistic_Derivact(sum);
                    break;
                case TypeNeuron.Output:
                    output = Exp(sum);
                  //  derivative = 
                    break;
            }
        }

        private double Logistic(double arg)
        {
            return 1 / (1 + Math.Exp(-arg));
        }

        private double Logistic_Derivact(double arg)
        {
            return Math.Exp(-arg) / ((1 + Math.Exp(-arg) * (1 + Math.Exp(-arg))));
        }

    }
}

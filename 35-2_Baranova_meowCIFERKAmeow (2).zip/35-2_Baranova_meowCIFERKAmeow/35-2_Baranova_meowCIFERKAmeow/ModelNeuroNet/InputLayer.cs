﻿

namespace _35_2_Baranova_meowCIFERKAmeow.ModelNeuroNet
{
    class InputLayer
    {
        //конструкторр
        public InputLayer(NetworkMode nm)
        { }
    }
}
